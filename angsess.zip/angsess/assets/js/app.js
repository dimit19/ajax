var app = angular.module("myApp", ["ngRoute","ngCookies"]);
app.config(function ($routeProvider) {
    $routeProvider
            .when("/", {
                templateUrl: "views/registration.html",
                
            })
            .when("/login", {
                templateUrl: "views/login.html"
                
            })
            .when("/dashboard", {
                templateUrl: "views/dashboard.html",
                controller: 'cookieCtrl'
            })
            .when("/about", {
                templateUrl: "views/about.html"
            })
            .when("/tikit", {
                templateUrl: "views/table.html",
                controller: 'homeCtrl'
            })
            .when("/contact", {
                templateUrl: "views/contact.html"
            });
});

