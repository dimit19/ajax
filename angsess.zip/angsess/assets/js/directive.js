var path = 'http://localhost/angsess/api/index.php/';
app.service("hexafy", ['$http', function ($http) {
        this.selectData = function (data, funcname) {
            return  $http({
                method: 'post',
                url: path + funcname,
                data: data,
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }).then(function (response) {
                return response.data['result'];

            }, function (error) {
                messages = 'can not get data.';
                return messages;
            });

        },
                this.insertData = function (data, funcname) {
                    return  $http({
                        method: 'post',
                        url: path + funcname,
                        data: data,
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                    }).then(function (response) {
                        messages = 'DATA INSERTED..'
                        return messages;

                    }, function (error) {
                        messages = 'can not get data.';
                        return messages;
                    });

                },
                this.updateData = function (data, funcname) {
                    return  $http({
                        method: 'post',
                        url: path + funcname,
                        data: data,
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                    }).then(function (response) {
                        messages = 'DATA UPDATED..'
                        return messages;

                    }, function (error) {
                        messages = 'can not get data.';
                        return messages;
                    });

                };
    }]);
