var path = 'http://localhost/angsess/api/index.php/';

// Registration 
app.controller("regForm", function ($scope, $http, $location) {
    $scope.user = {};
    $scope.registrationForm = function ()
    {
        $http({
            method: 'post',
            url: path + 'welcome/index',
            data: $scope.user
        }).then(function (response) {
            alert(response.data['status']);
            $('#email').val('');
            $('#pwd').val('');
            if (response.data['success'] == 1)
            {
                $location.path('/login');
            }
        }, function (error) {
            console.log(error, 'can not get data.');
        });
    };

});
// login
app.controller('logForm', ['$rootScope', '$scope', '$http', '$location', '$cookies', '$cookieStore', function ($rootScope, $scope, $http, $location, $cookies, $cookieStore) {
        $scope.user = {};

        $scope.loginForm = function ()
        {
            $http({
                method: 'post',
                url: path + 'welcome/login',
                data: $scope.user
            }).then(function (response) {
                // console.log(response);
                // alert(response.data['status']);
                if (response.data['success'] == 1)
                {
                    id = response.data['result'][0]['id'];
                    $cookies.put('userdata', JSON.stringify(response.data['result']));
                    loginlog(id); // call loginlog dunction
                }
            }, function (error) {
                console.log(error, 'can not get data.');
            });
        };
        function loginlog(id)
        {
            $http({
                method: 'post',
                url: path + 'welcome/loginlog',
                data: {id: id}
            }).then(function (response) {
                if (response.data['success'] == 1)
                {
                    $cookies.put('logid', response.data['result']);
                    $location.path('/dashboard');
                }
            }, function (error) {
                console.log(error, 'can not get data.');
            });
        }


    }]);
app.controller('cookieCtrl', ['$rootScope', '$scope', '$http', '$location', '$cookies', '$cookieStore', 'hexafy', function ($rootScope, $scope, $http, $location, $cookies, $cookieStore, hexafy) {
        if ($cookies.get("userdata") == undefined || $cookies.get("userdata") == "") {
            $location.path('/login');
            return false;
        }

        var jsonObj = JSON.parse($cookies.get("userdata"));

        for (var i = 0; i < jsonObj.length; i++)
        {
            $scope.username = jsonObj[i]['email'];
            $scope.id = jsonObj[i]['id'];
        }
        $scope.logout = function ()
        {
            data = {id: $cookies.get("logid")};
            funcname = 'welcome/logouthistory';
            hexafy.updateData(data, funcname);
            $cookieStore.remove("userdata");
            $cookieStore.remove("logid");
            $location.path('/login');
        };
        //id = $scope.id;
        data = {id: $scope.id};
        funcname = 'welcome/loginhistory';

        hexafy.selectData(data, funcname).then(function (dataresult) {
            $rootScope.data = dataresult;
        });
    }]);

