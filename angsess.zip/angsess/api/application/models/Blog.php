<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog extends CI_Model {

    public function login($request) {

        $this->db->select('*');
        $this->db->from('registration');
        $this->db->where('email', $request['email']);
        $this->db->where('password', $request['pwd']);
        $query = $this->db->get();
        $result = $query->result_array();
        return $result;
    }

    public function registration($request) {
        $this->db->select('*');
        $this->db->from('registration');
        $this->db->where('email', $request['email']);
        $query = $this->db->get();
        $result = $query->result_array();
        $count = count($result);
        if ($count == 0) {
            $this->password = $request['pwd']; // please read the below note
            $this->email = $request['email'];
            $result = $this->db->insert('registration', $this);
        } else {
            $result = "2";
        }

        return $result;
    }

    public function loginstatus($request) {
        $date = date('Y-m-d H:i:s');
        $this->regid = $request['id'];
        $this->intime = $date; // please read the below note
        $result = $this->db->insert('loginstatus', $this);
        $insert_id = $this->db->insert_id();
        return $insert_id;
    }

    public function logouthistorylog($request) {
        $date = date('Y-m-d H:i:s');
        $this->db->set('outtime', $date); //value that used to update column  
        $this->db->where('id', $request['id']); //which row want to upgrade  
        $result = $this->db->update('loginstatus');  //table name
        return $result;
    }

    public function loginhistorylog($request) {

        $this->db->select('*');
        $this->db->from('loginstatus');
        $this->db->where('regid', $request['id']);
        $query = $this->db->get();
        $result = $query->result_array();
        return $result;
    }

    public function get_subjects($top) {
        $this->db->select('*');
        $this->db->from('subjectlist');
        $this->db->where('iStandardId', $top['standard']);
        $query = $this->db->get();
        $result = $query->result_array();
        ?>
        <?php
        $value = array();
        foreach ($result as $val) {
            ?> 
            <p><?php echo $val['vSubjectName'] . " = "; ?></p> <input type="text" data-id="<?php echo $val['iSubjectId']; ?>" class="form-control subject" id="subname" name="subname[]"><br/>		
            <?php
        }
        ?>
        <button type="submit" name="submit" id="submit" class="btn btn-default">Submit</button>
        <?php
        return true;
    }

    public function insert_subjects_marks($data) {
        for ($i = 0; $i < count($data['subjectmarks']); $i++) {
            $insert[] = array(
                "iSubjectId" => $data['subjectname'][$i],
                "iStudentId" => $data['studentname'],
                "iStandardId" => $data['standard'],
                "marks" => $data['subjectmarks'][$i]
            );
        }

        $result = $this->db->insert_batch('marks', $insert);
        return $result;
    }

    public function marksDetails($data) {

        $this->db->select('marks.iSubjectId,subjectlist.vSubjectName');
        $this->db->from('marks');
        $this->db->group_by('marks.iSubjectId');
        $this->db->join('subjectlist', 'subjectlist.iSubjectId = marks.iSubjectId');
        $this->db->where('marks.iStandardId', $data);
        $query = $this->db->get();
        $result1 = $query->result_array();
        return $result1;
    }

    public function marksCOunt($standardid, $subjectid, $studentid) {

        $this->db->select('marks.marks');
        $this->db->from('marks');
        $this->db->where('marks.iStandardId', $standardid);
        $this->db->where('marks.iStudentId', $studentid);
        $this->db->where('marks.iSubjectId', $subjectid);
        $query = $this->db->get();
        $result2 = $query->result_array();
        return $result2;
    }

    public function failCOunt($standardid, $studentid) {
        $this->db->select('marks.marks');
        $this->db->from('marks');
        $this->db->where('marks.iStandardId', $standardid);
        $this->db->where('marks.iStudentId', $studentid);
        $this->db->where('marks.marks > 40');
        $query = $this->db->get();
        $result = $query->result_array();
        $count = count($result);
        return $count;
    }

    public function resultDisplay($data) {
        $this->db->select('studentlist.vFirstName,studentlist.vRollNumber,subjectlist.vSubjectName,marks.marks,marks.iStudentId,marks.iSubjectId');
        $this->db->from('marks');
        $this->db->join('subjectlist', 'subjectlist.iSubjectId = marks.iSubjectId');
        $this->db->join('studentlist', 'studentlist.iStudentId = marks.iStudentId');
        $this->db->group_by('marks.iStudentId');
        $this->db->where('marks.iStandardId', $data['standard']);
        $query = $this->db->get();
        $result = $query->result_array();

        $result2 = $this->marksDetails($data['standard']);
        ?>		
        <table style="width:100%">
            <tr>
                <th>studentrollnumber</th>
                <th>studentname</th>
                <th>standard</th>
                <?php foreach ($result2 as $subjectname) { ?>
                    <th><?php echo $subjectname['vSubjectName'] ?></th>
                <?php } ?>
                <th>total</th>						
                <th>result</th>
                <th>Number of subject pass</th>
            </tr>
            <?php
            $sum = 0;
            foreach ($result as $val) {
                ?>
                <tr>
                    <td><?php echo $val['vRollNumber']; ?></td>
                    <td><?php echo $val['vFirstName']; ?></td>
                    <td><?php echo $data['standard']; ?></td> 

                    <?php foreach ($result2 as $subjectname) { ?>
                        <td><?php
                            $test = $this->marksCOunt($data['standard'], $subjectname['iSubjectId'], $val['iStudentId']);
                            echo $test[0]['marks'];
                            $sum += $test[0]['marks'];
                            ?></td>
                    <?php } ?>
                    <td> <?php echo $sum; ?> </td>							

                    <td <?php
                    if ($val['marks'] < 40) {
                        echo "style='color:red;'";
                    } else {
                        echo "style='color:green;'";
                    }
                    ?>><?php
                            if ($val['marks'] < 40) {
                                echo "fail";
                            } else {
                                echo "pass";
                            }
                            ?></td>
                    <td> <?php
                        $test = $this->failCOunt($data['standard'], $val['iStudentId']);
                        print_r($test);
                        ?> </td>
                </tr>

            <?php } ?>

        </table>
        <?php
        return true;
    }

}
?>