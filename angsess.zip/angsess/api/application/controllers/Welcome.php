<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('blog');
    }

    public function index() {
        $json = file_get_contents('php://input');
        $request = json_decode($json, TRUE);
        $result = $this->blog->registration($request);
        if ($result == 1) {
            $msg['success'] = "1";
            $msg['status'] = "DATA INSERTED SUCCESFULLY..";
            echo json_encode($msg);
        } else if ($result == 2) {
            $msg['success'] = "0";
            $msg['status'] = "EMAIL ALREADY REGISTER..";
            echo json_encode($msg);
        } else {
            $msg['success'] = "0";
            $msg['status'] = "DATA NOT INSERTED SUCCESFULLY..";
            echo json_encode($msg);
        }
    }

    public function login() {
        $json = file_get_contents('php://input');
        $request = json_decode($json, TRUE);
        $result = $this->blog->login($request);

        if (!empty($result)) {
            $msg['success'] = "1";
            $msg['status'] = "LOGGIN SUCCESFULLY..";
            $msg['result'] = $result;
            echo json_encode($msg);
        } else {
            $msg['success'] = "0";
            $msg['status'] = "EMAIL OR PASSWORD IS WRONG..";
            echo json_encode($msg);
        }
    }

    public function loginlog() {
        $json = file_get_contents('php://input');
        $request = json_decode($json, TRUE);
        $result = $this->blog->loginstatus($request);

        if (!empty($result)) {
            $msg['success'] = "1";
            $msg['status'] = "LOG INSERTED SUCCESFULLY..";
            $msg['result'] = $result;
            echo json_encode($msg);
        } else {
            $msg['success'] = "0";
            $msg['status'] = "LOG NOT INSERTED SUCCESFULLY..";
            echo json_encode($msg);
        }
    }
    public function loginhistory()
    {
        $json = file_get_contents('php://input');
        $request = json_decode($json, TRUE);
        $result = $this->blog->loginhistorylog($request);

        if (!empty($result)) {
            $msg['success'] = "1";
            $msg['result'] = $result;
            echo json_encode($msg);
        } else {
            $msg['success'] = "0";
            $msg['status'] = "ID NOT GETTING..";
            echo json_encode($msg);
        } 
    }
     public function logouthistory()
    {
        $json = file_get_contents('php://input');
        $request = json_decode($json, TRUE);
        $result = $this->blog->logouthistorylog($request);

        if (!empty($result)) {
            $msg['success'] = "1";
            $msg['result'] = $result;
            echo json_encode($msg);
        } else {
            $msg['success'] = "0";
            $msg['status'] = "ID NOT GETTING..";
            echo json_encode($msg);
        } 
    }
    

}
